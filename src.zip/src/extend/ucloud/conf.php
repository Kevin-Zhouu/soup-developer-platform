<?php

global $SDK_VER;
global $UCLOUD_PROXY_SUFFIX;
global $UCLOUD_PUBLIC_KEY;
global $UCLOUD_PRIVATE_KEY;

$SDK_VER = "1.0.8";

//空间域名后缀,请查看控制台上空间域名再配置此处
$UCLOUD_PROXY_SUFFIX = '.cn-sh2.ufileos.com';

$UCLOUD_PUBLIC_KEY = 'TOKEN_bb80c6a3-5950-44f7-b85a-bb573318b4cc';
$UCLOUD_PRIVATE_KEY = '2bf839ff-3a16-413b-a23e-b1ca651ef95f';
