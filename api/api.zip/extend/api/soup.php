<?php
namespace api\helper;
class soup{
	static public function date($data,$format="Y-m-d"){
		return(date($format,strtotime($data)));
	}
	static public function connectRedis(){
		$redis = new \Redis();
		$redis->connect('127.0.0.1', 6379);
		return($redis);
	}
}
?>