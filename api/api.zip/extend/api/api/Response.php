<?php
namespace api;
use \think\Request;
class Response{
	static $msg=array(
		'200'=>'Ok',
		'400'=>'Bad Request',
		'404'=>'Not Found',
		'403'=>'Reqiest Forbidden',
		'500'=>'Server Error',
	);
	public static function returnMsg($msg,$error_code,$responseType="none"){
		$data=['code'=>$error_code,'data'=>$msg];
		self::response($data,$responseType);
	}
	public static function response($data,$type){
		if($type=='json') {
			echo json_encode($data);
		}
		//dump($data['data']);
		if($type=='text'||$type="none"){
			echo $data['data'];
		}
		
		
	}
}