<?php
namespace api;
use \think\Session;
use \think\Controller;
use \think\Db;
use \api\model\Apps;
use \think\Validate;
class AppControl{
	static public function test(){
		echo get_rand_str(100);
	}  
	static public function newApp($app_name,$app_description="",$app_owner,$app_version){
		$validate_data=[
				'appName'			=>	$app_name,
				'appDescription'	=>	$app_description,
				'appOwner'			=>	$app_owner,
				'appVersion'		=>	$app_version
			];
		$validate = new validate(
			[
				'appName'			=>	'require|max:15|min:2',
				'appDescription'	=>	'max:200', 
				'appOwner'			=>	'require', 
				'appVersion'		=>	'require|max:100',
			]);
		if(!$validate->check($validate_data)) return ['status'=>'500','data'=>['error'=>$validate->getError()]];
		else{
			$app_key=get_rand_str(60);
			$status= Apps::insert([
				'appname'		=>	$app_name,
				'description'	=>	$app_description,
				'owner'			=>	$app_owner,
				'appkey'		=>	$app_key,
				'version'		=>	$app_version
			]);
			if($status){
				return ['status'=>'200','data'=>['msg'=>'success']];
			}else{
				return ['status'=>'503','data'=>['error'=>'Internal server error']];
			}
		}
					
	}
}

