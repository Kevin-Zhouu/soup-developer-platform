<?php
namespace api\helper;
class soup{
	static public function date($data,$format="Y-m-d"){
		return(date($format,strtotime($data)));
	}
}
?>