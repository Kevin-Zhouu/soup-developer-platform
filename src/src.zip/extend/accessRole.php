<?php
namespace soup;
use \think\Session;
use \think\Controller;
use \think\Db;
class Role extends Controller{
	public static $user_role;
	public static $page_accessRole;
	public static $all_role;
	public static $all_action;
	public static function viewPermission($page,$user="NULL"){
		if($user!=""){
			if(@self::$all_role[self::$user_role][$page]==NULL){
				die(pageBack('您没有权限浏览此页面！正在返回上一页'));
			}else{
				return true;
			}
		}else{
			$user_role=self::getUserRole($user);
			if(@self::$all_role[$user_role][$page]==NULL){
				return false;
			}else{
				return true;
			}
		}
		//$p=$role=="" ? "good" : "bad";
	}
	public static function checkPermission($result){
		if($result){
			die(pageBack('您没有权限浏览此页面！正在返回上一页'));
		}else{
			return true;
		}
	}
	public static function getUserRole($user=""){
		if($user==""){
			if(@Session::get('user')->role!=null){
				$result=Session::get('user')->role;
			}else{
				$result="visitor";
			}
		}else{
			$data=Db::table('user')->where(['name'=>$user])->find();
			$result=$data['role'];
		}
		return($result);
		//		$result=@Session::get($user['role'])!=null ? @Session::get($user['role']) : "visitor";
	}
	protected function _initialize(){
		//self::$test1="23";
	}
}
start();
function start(){
	$allAction = Db::table('action')->select();
	$allRole = Db::table('role')->select();
	for($i=0;$i<count($allAction);$i++){
		Role::$all_action[$allAction[$i]['name']]=$allAction[$i]['aid'];
	}
	for($i=0;$i<count($allRole);$i++){
		Role::$all_role[$allRole[$i]['name']][$allRole[$i]['action']]=$allRole[$i]['rid'];
	}
	Role::$user_role=Role::getUserRole();
//	for($i=0;$i<count($allRole);$i++){
//		echo $allRole[$i]['name'];
//	}
	//echo $i;
	//var_dump(Role::$all_action);
	//var_dump(Role::$all_role);
	//var_dump( Role::getUserRole('admin2'));
	//var_dump($allRole);
}
function pageBack($text){
	$res=<<<EOT
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
<link rel="stylesheet" href="/static/css/bootstrap.min.css" >
<script src="/static/js/jquery-3.3.1.slim.min.js"> </script>
<script src="/static/js/popper.min.js"> </script>
<script src="/static/js/bootstrap.min.js"> </script>
<script src="/static/js/layer/layer.js"></script>
</head>

<body>
	<script>layer.msg('$text', {icon: 0,time:3000,end:function(){
			history.back(-2)
		}});
			
		
	
  </script>


</body>
</html>

EOT;
	return $res;
}