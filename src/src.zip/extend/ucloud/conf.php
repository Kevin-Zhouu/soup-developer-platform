<?php

global $SDK_VER;
global $UCLOUD_PROXY_SUFFIX;
global $UCLOUD_PUBLIC_KEY;
global $UCLOUD_PRIVATE_KEY;

$SDK_VER = "1.0.8";

//空间域名后缀,请查看控制台上空间域名再配置此处
$UCLOUD_PROXY_SUFFIX = '.cn-sh2.ufileos.com';

$UCLOUD_PUBLIC_KEY = 'eCjXOr27dcTyWE1Ta3ovpm0Z+TEzz48g8cMNdR6OoKTjryCrT1YbkQ==';
$UCLOUD_PRIVATE_KEY = '322950e4a9d4b99b36ca407a014b2b214ac06a9b';
