<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:75:"P:\Projects\phpRedisX\src\public/../application/index\view\index\index.html";i:1546352501;s:69:"P:\Projects\phpRedisX\src\application\index\view\common\template.html";i:1546352616;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="/static/css/bootstrap.min.css" >
<link rel="stylesheet" href="/static/css/system.css" >
<script src="/static/js/jquery-3.3.1.slim.min.js"> </script>
<script src="/static/js/popper.min.js"> </script>
<script src="/static/js/bootstrap.min.js"> </script>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm  soup-topnav "> 
	<a class="navbar-brand soup-nav-whiteColor" href="#">大汤易语言平台</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse soup-navcontent" id="navbarSupportedContent" >
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active"> <a class="nav-link soup-nav-subtitle" href="#">首页 <span class="sr-only">(current)</span></a> </li>
      <li class="nav-item active"> <a class="nav-link soup-nav-subtitle" href="#">特点 <span class="sr-only">(current)</span></a> </li>
      <li class="nav-item active"> <a class="nav-link soup-nav-subtitle" href="#">优势 <span class="sr-only">(current)</span></a> </li>
		<li class="nav-item active"> <a class="nav-link soup-nav-subtitle" href="#">下载 <span class="sr-only">(current)</span></a> </li>
      
    </ul>
    <div class="form-inline my-2 my-lg-0">
	  
		<?php switch($login_status): case "1": ?>
				<img width='30px' src="static/img/avatar_user.png"/>
				<a class="nav-link soup-nav-subtitle" >您好,<?php echo $user_name; ?></a>
				<button class="btn btn-outline-primary rounded-0" onClick="window.location.href='/index.php/admin/manage/index'" >管理控制台</button>
			<?php break; case "0": ?>
				<button class="btn btn-primary my-2 my-sm-0"  onClick="window.location.href='/index.php/admin/login/index'">登录</button>
				  <span style="margin-left: 5px"></span>
				  <button class="btn btn-outline-success my-2 my-sm-0" onClick="window.location.href='/index.php/admin/login/signup'">注册</button>
			<?php break; endswitch; ?>
		  
	  
    </div>
  </div>
</nav>
<div class="soup-frame shadow-lg bg-black">
	<div class="soup-background ">
		<div class="soup-background2 "></div>
		<div class="soup-topcontent center-block">
			<div class="soup-topcontent1 wow fadeInUp animated" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInRight;">
				<h1>大汤易语言平台</h1>
				<p>易用，快捷，安全</p>
				<button class="btn btn-primary my-2 my-sm-0" >立即使用</button>
				<button class="btn btn-outline-danger my-2 my-sm-0" >查看文档</button>

			</div>
		</div>
	</div>
</div>


</body>
</html>
