<?php
namespace api\model;
use think\Model;
use \think\Session;
use \think\Db;
use \api\model\Apps;
use \api\helper\soup;
use \think\Validate;
class Apps extends Model{
	static public function newApp($app_name,$app_description="",$app_owner,$app_version){
		$validate_data=[
				'appName'			=>	$app_name,
				'appDescription'	=>	$app_description,
				'appOwner'			=>	$app_owner,
				'appVersion'		=>	$app_version
			];
		$validate = new validate(
			[
				'appName'			=>	'require|max:15|min:2',
				'appDescription'	=>	'max:200', 
				'appOwner'			=>	'require', 
				'appVersion'		=>	'require|max:100',
			]);
		if(!$validate->check($validate_data)) return ['status'=>'500','data'=>['error'=>$validate->getError()]];
		else{
			$app_key=get_rand_str(60);
			$isAlready=Apps::where(['appname'=>$app_name])
					->whereOr(['appkey'=>$app_key])
					->find();
			if($isAlready) return ['status'=>'500','data'=>['error'=>'Appname already exist']];
			else{
				$status= Apps::insert([
					'appname'		=>	$app_name,
					'description'	=>	$app_description,
					'owner'			=>	$app_owner,
					'appkey'		=>	$app_key,
					'version'		=>	$app_version
				]);

				if($status){
					return ['status'=>'200','data'=>['msg'=>'success']];
				}else{
					return ['status'=>'503','data'=>['error'=>'Internal server error']];
				}
			}
		}
	}
	static public function editApp($app_id,$app_name,$app_description="",$app_version){
		$validate_data=[
				'appName'			=>	$app_name,
				'appDescription'	=>	$app_description,
				'appId'				=>	$app_id,
				'appVersion'		=>	$app_version
			];
		$validate = new validate(
			[
				'appName'			=>	'require|max:15|min:2',
				'appDescription'	=>	'max:200', 
				'appId'			=>	'require', 
				'appVersion'		=>	'require|max:100',
			]);
		if(!$validate->check($validate_data)) return ['status'=>'500','data'=>['error'=>$validate->getError()]];
		else{
			$status= Apps::where(['id'=>$app_id])->update([
				'appname'		=>	$app_name,
				'description'	=>	$app_description,
				'version'		=>	$app_version
			]);

			if($status){
				return ['status'=>'200','data'=>['msg'=>'success']];
			}else{
				return ['status'=>'503','data'=>['error'=>'Internal server error']];
			}
			
		}
	}
	static public function getAppDetail($app_key){
		return(Apps::get(['appkey'=>$app_key]));
	}
}
class App_analysis extends Model{
	static public function getAnalysis($aid,$name,$time="0"){
		$app_original_res = self::where([
			'aid'=>$aid,
			'name'=>$name,
		])->whereTime('date', $time)->select();
		$app_res=[];
		foreach($app_original_res as $val){
            $app_res[date('Y-m-d',strtotime($val->date))]=$val->toArray();
        }
		return ($app_res);
		
	}
	static public function updateView($app_key){
		$app=Apps::getAppDetail($app_key);
		$analysis=self::getAnalysis($app['id'],'use','today');
		$ip_analysis=self::getAnalysis($app['id'],'ip','today');
		if($app==NULL){
			$status=404;
		}else{
			if($analysis==NULL){
				$data=self::insert([
					'aid'=>$app['id'],
					'name'=>'use',
					'data'=>1
					
				]);
			}else{
				
				$data=self::where([
					'aid'=>$app['id'],
					'date'=>$analysis[date('Y-m-d')]['date'],
					'name'=>'use',
				])->update(['data'=>$analysis[date('Y-m-d')]['data']+1]);
			}
			//ip part
			$redis = soup::connectRedis();
			$ip=$_SERVER['REMOTE_ADDR'];
			$key="ip_".$app['id'];
			if($redis->hGet($key,$ip)!='true'){
				$redis->hSet($key,$ip,'true');
				$expireTime = mktime(23, 59, 59, date("m"), date("d"), date("Y"));
				$redis->expireAt($key, $expireTime);
				if($ip_analysis==NULL){
					$data=self::insert([
						'aid'=>$app['id'],
						'name'=>'ip',
						'data'=>1

					]);
				}else{
					$data=self::where([
						'aid'=>$app['id'],
						'date'=>$ip_analysis[date('Y-m-d')]['date'],
						'name'=>'ip',
					])->update(['data'=>$ip_analysis[date('Y-m-d')]['data']+1]);
				}
			}
			
			$status=200;
			
		}
		
		
		return($status);
	}
	
	
}
